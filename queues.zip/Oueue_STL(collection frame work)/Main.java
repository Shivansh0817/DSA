import java.util.*;
public class Main
{
    public static void main(String args[])
    {
        Queue<Integer> qu=new LinkedList<>();/*we cant use new Queue<>(),we can use only LinkedList<>()/ArrayDeque<>() in queue.*/
        qu.add(3);
        qu.add(4);
        qu.add(5);
        qu.add(5);
        qu.add(5);
        System.out.println(qu);
        qu.remove();/*or qu.poll()*/
        System.out.println(qu);
        System.out.println(qu.peek());/*or qu.element(),it gives the front value*/
        System.out.println(qu.size());
    }
}