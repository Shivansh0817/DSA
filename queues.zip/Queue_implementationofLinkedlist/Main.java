public class Main
{
  static class Node
  {
	Node next;
	int data;

	  Node (int d)
	{
	  data = d;
	  next = null;
	}
  }
  public static class Queuel
  {
	Node front;
	Node rear;
	void enque (int d)
	{
	  Node newnode = new Node (d);
	  if (front == null)
		{
		  front = newnode;
		  rear = newnode;
		  return;
		}
	  rear.next = newnode;
	  rear = newnode;
	}
	int deque()
	{
	  if (front == null)
		{
		  return -1;
		}
		int res=front.data;
		front=front.next;
		return res;
	}
	void display()
	{
	    Node temp=front;
	    while(temp.next!=null)
	    {
	        System.out.println(temp.data);
	        temp=temp.next;
	    }
	}
  }
  public static void main(String args[])
  {
      Queuel obj=new Queuel();
      obj.enque(1);
      obj.enque(6);
      obj.enque(2);
      obj.enque(4);
      obj.enque(3);
      obj.display();
      System.out.println("After dequing the queue :" + obj.deque());
      obj.display();
      
  }
}
