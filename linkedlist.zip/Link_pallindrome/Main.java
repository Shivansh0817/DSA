public class Main {
Node head;
class Node
{
    int data;
    Node next;
    
    Node(int d)
    {
        data=d;
        next=null;
    }
}
void add(int d,Node head,int pos)
{
    Node newnode=new Node(d);
    if(pos==0)
    {
     newnode.next=head;
     head=newnode;
    }
    Node prev=head;
    for(int i=0;i<pos;i++)
    {
        prev=prev.next;
    }
    newnode.next=prev.next;
    prev.next=newnode;
}
Node middle(Node head)
{
   int n=0;
   Node temp=head;
   while(temp!=null)
   {
       n++;
       temp=temp.next;
   }
   int half=n/2;
   temp=head;
   for(int i=0;i<half;i++)
   {
       temp=temp.next;
   }
   return temp;
}
   void print()
            {
               if(head==null)
                {
                 System.out.println("List is empty");
                return;
                } 
            Node last=head;
            while(last!=null)
                {
                 System.out.println(last.data);
                last=last.next;
                }
            }
public static void main(String args[])
{
    Main obj=new Main();
    obj.add(3,obj.head,0);
    obj.add(4,obj.head,1);
    obj.add(5,obj.head,2);
    obj.add(6,obj.head,3);
    obj.add(7,obj.head,4);
    obj.add(8,obj.head,5);
    obj.print();
}
}