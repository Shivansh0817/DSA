public class Main {
    Node head;
    
    static class Node {
        Node next;
        int data;
        
        Node(int d) {
            data = d;
            next = null;
        }
    }

    Node getIntersection(Node headA, Node headB) {
        int siza = 0, sizb = 0;
        Node tempA = headA;
        Node tempB = headB;

        while (tempA != null) {
            tempA = tempA.next;
            siza++;
        }

        while (tempB != null) {
            tempB = tempB.next;
            sizb++;
        }

        tempA = headA;
        tempB = headB;

        if (siza > sizb) {
            int k = siza - sizb;
            for (int i = 0; i < k; i++) {
                tempA = tempA.next;
            }
        } else {
            int k = sizb - siza;
            for (int i = 0; i < k; i++) {
                tempB = tempB.next;
            }
        }

        while (tempA != null && tempB != null) {
            if (tempA == tempB) {
                return tempA;
            }
            tempA = tempA.next;
            tempB = tempB.next;
        }

        return null; // No intersection
    }

    public static void main(String[] args) {
        Main obj = new Main();

        // Creating linked lists
        Node headA = new Node(10);
        Node headB = new Node(3);

        Node newNode = new Node(6);
        headB.next = newNode;

        newNode = new Node(9);
        headB.next.next = newNode;

        newNode = new Node(15);
        headA.next = newNode;
        headB.next.next.next = newNode;

        newNode = new Node(30);
        headA.next.next = newNode;

        headA.next.next.next = null;

        Node intersectionPoint = obj.getIntersection(headA, headB);

        if (intersectionPoint == null) {
            System.out.println("Null");
        } else {
            System.out.println(intersectionPoint.data);
        }
    }
}
