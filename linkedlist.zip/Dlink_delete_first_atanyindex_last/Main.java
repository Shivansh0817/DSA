public class Main 
{
    Node head;
    class Node
    {
        int data;
        Node next;
        Node prev;
        Node(int d)
        {
            data=d;
            prev=null;
            next=null;
        }
    }
    void addfirst(int d)
    {
        Node newnode=new Node(d);
        {
            if(head==null)
            {
                head=newnode;
                return;
            }
            newnode.next=head;
            head=newnode;
            head.prev=null;
        }
    }
    void atanyindex(int d,Node head,int pos)
    {
        Node newnode=new Node(d);
        if(pos==0)
        {
            newnode.next=head;
            head=newnode;
            head.prev=null;
        }
        Node temp=head;
        for(int i=1;i<pos-1;i++)
        {
             temp=temp.next;
        }
        newnode.next=temp.next;
        temp.next.prev=newnode;
        temp.next=newnode;
        newnode.prev=temp;
    }
    void deletehead()
    {
        if(head==null)
        {
            System.out.println("List is empty");
            return;
        }
        head=head.next;
        head.prev=null;
    }
    void deletelast()
    {
        if(head==null)
        {
            System.out.println("List is empty");
        }
        Node curr=head;
        while(curr.next!=null)
        {
            curr=curr.next;
        }
        curr=curr.prev;
        curr.next=null;
    }
    void deleteatanyindex(Node head,int pos)
    {
        if(head==null)
        {
            System.out.println("List is empty");
        }
        Node temp=head;
        for(int i=1;i<pos-1;i++)
        {
            temp=temp.next;
        }
        temp.next=temp.next.next;
        temp.next.prev=temp;
    }
    
    void display()
    {
        if(head==null)
        {
            System.out.println("List is empty");
        }
        Node temp=head;
        while(temp!=null)
        {
            System.out.println(temp.data);
            temp=temp.next;
        }
    }
      public static void main (String[] args)
      {
          Main obj=new Main();
          obj.addfirst(3);
          obj.addfirst(4);
          obj.addfirst(5);
          obj.addfirst(6);
          obj.addfirst(7);
          obj.atanyindex(9,obj.head,4);
          obj.display();
          System.out.println("After deleting");
          obj.deleteatanyindex(obj.head,4);
          obj.display();
      }
}
    
