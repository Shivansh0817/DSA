public class Main 
{
    Node head;
    class Node()
    { 
        int data;
        Node next;
        Node prev;
        Node(int d)
        {
            data=d;
            next=null;
            prev=null;
        }
    }
        void addfirst(int d)
        {
            Node newnode=new Node(d);
            if(head==null)
            {
                head=newnode;
                prev=newnode;
                return;
            }
            prev=head;
            while(prev.next!=null)
            {
                prev=prev.next;
            }
            newnode.prev=prev.next;
            newnode.next=head.prev;
            head=newnode;
            prev=newnode.prev;
            
        }
        void display()
        {
            if(head==null)
            {
                System.out.println("list is empty");
            }
            Node curr=head;
            while(curr!=null)
            {
                System.out.println(curr.data);
                curr=curr.next;
                
            }
        }
         public static void main (String[] args)
         {
             Main obj=new Main();
             obj.addfirst(4);
             obj.addfirst(5);
             obj.addfirst(6);
             obj.display();
         }
}