public class Main
{
Node head;
class Node
{
    int data;
    Node next;

Node(int d)
{
 data=d;
    next=null;
}

}

 void addfirst(int d)
            {
                Node newnode=new Node(d);
                if(head==null)
                {
                    head=newnode;
                    return;
                }
                newnode.next= head;
                head= newnode;
            }
            void atanyindex(int d,Node head,int pos)
            {
                Node newnode=new Node(d);
                if(pos==0)
                {
                    newnode.next=head;
                    newnode=head;
                    return;
                }
                Node prev=head;
                for(int i=0;i<pos-1;i++)
                {
                   prev=prev.next; 
                }
                newnode.next=prev.next;
                prev.next=newnode;
            }
            void addlast(int d)
            {
                Node newnode=new Node(d);
                if(head==null)
               {
                   head=newnode;
                   return;
               }
                Node last=head;
                while(last.next!=null)
                {
                    last=last.next;
                }
                last.next=newnode;
            }
            void print()
{
    if(head==null)
    {
        System.out.println("List is empty");
        return;
    }
    Node last=head;
    while(last!=null)
    {
        System.out.println(last.data);
        last=last.next;
    }
}
public static void main(String args[])
{
    Main obj=new Main();
    obj.print();
    obj.addfirst(5);
    obj.addfirst(6);
    obj.addfirst(7);
    obj.addlast(12);
    obj.print();
    obj.atanyindex(3,obj.head,3);
    obj.print();
}
}