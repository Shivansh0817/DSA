public class Main
{
Node head;
class Node
{
    int data;
    Node next;

Node(int d)
{
 data=d;
    next=null;
}

}

 void addfirst(int d)
            {
                Node newnode=new Node(d);
                if(head==null)
                {
                    head=newnode;
                    return;
                }
                newnode.next= head;
                head= newnode;
            }
            Node getmiddle(Node head)
            {
                int n=0;
                Node temp=head;
                while(temp!=null)
                {
                    n++;
                    temp=temp.next;
                }
                int half=n/2;
                temp=head;
                for(int i=0;i<half;i++)
                {
                    temp=temp.next;
                }
                return temp;
            }

            void addlast(int d)
            {
                Node newnode=new Node(d);
                if(head==null)
               {
                   head=newnode;
                   return;
               }
                Node last=head;
                while(last.next!=null)
                {
                    last=last.next;
                }
                last.next=newnode;
            }
            void print()
{
    if(head==null)
    {
        System.out.println("List is empty");
        return;
    }
    Node last=head;
    while(last!=null)
    {
        System.out.println(last.data);
        last=last.next;
    }
}
public static void main(String args[])
{
    Main obj=new Main();
    obj.print();
    obj.addfirst(5);
    obj.addfirst(6);
    obj.addfirst(7);
    obj.addlast(12);
    obj.addlast(13);
    obj.addlast(14);
    obj.print();
    Node middle=obj.getmiddle(obj.head);
    System.out.println("The middle element is:"+ (middle!=null?middle.data:"List is empty"));
    obj.print();
}
}