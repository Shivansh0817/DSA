public class Main
{
Node head;
class Node
    {
        int data;
        Node next;
        Node prev;
        Node(int d)
        {
            data =d;
            next=null;
            prev=null;
        }
    }
    void addfirst(int d)
    {
        Node newnode=new Node(d);
        if(head==null)
        {
            head=newnode;
            return;
        }
        newnode.next=head;
        newnode.prev=null;
        head.prev=newnode;
        head=newnode;
    }
    void addlast(int d)
    {
        Node newnode=new Node(d);
        if(head==null)
        {
            head=newnode;
            return;
        }
        Node last=head;
        while(last.next!=null)
        {
            last=last.next;
        }
        last.next=newnode;
        newnode.prev=last;
        newnode.next=null;
        last=newnode;
    }
    void atanyindex(int d,Node head,int pos)
    {
        Node newnode=new Node(d);
        if(pos==0)
        {
            newnode.next=head;
            newnode.prev=null;
            head.prev=newnode;
            head=newnode;
        }
        Node temp=head;
        for(int i=0;i<pos-1;i++)
        {
         temp=temp.next;   
        }
        newnode.next=temp.next;
        temp.prev=newnode;
        newnode.prev=temp;
        temp.next=newnode;
    }
    void reverse(Node head)
    {
        if (head == null) return;
        Node temp=head;
        while(temp.next!=null)
        {
            temp=temp.next;
        }
        while(temp!=null)
        {
            System.out.println(temp.data);
            temp=temp.prev;
        }
    }
    void print()
    {
        if(head==null)
        {
            System.out.println("List is empty");
        }
        Node curr=head;
        while(curr!=null)
        {
            System.out.println(curr.data);
            curr=curr.next;
        }
    }
    public static void main(String args [])
    {
        Main obj= new Main();
        obj.addfirst(3);
        obj.addfirst(4);
        obj.addfirst(5);
        obj.addfirst(6);
        obj.addfirst(7);
        obj.addfirst(8);
        obj.addlast(9);
        obj.atanyindex(10,obj.head,3);
        obj.print();
        obj.reverse(obj.head);
        obj.print();
    }
}
    

