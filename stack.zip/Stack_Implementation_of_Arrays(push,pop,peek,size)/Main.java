public class Main {
    int arr[] = new int[10];
    int indx = 0;

    // Push method to add element to the stack
    void push(int x) {
        if (isFull()) {
            System.out.println("Stack is full");
            return;  // Exit the method if the stack is full
        }
        arr[indx] = x;
        indx++;
    }

    // Peek method to view the top element of the stack
    int peek() {
        if (indx == 0) {
            System.out.println("Stack is empty");
            return -1;
        }
        return arr[indx - 1];
    }

    // Size method to get the current size of the stack
    int size() {
        return indx;
    }

    // Pop method to remove the top element of the stack
    int pop() {
        if (indx == 0) {
            System.out.println("Stack is empty");
            return -1;
        }
        int top = arr[indx - 1];
        arr[indx - 1] = 0;
        indx--;
        return top;  // Return the popped element
    }

    // isEmpty method to check if the stack is empty
    boolean isEmpty() {
        return indx == 0;
    }

    // isFull method to check if the stack is full
    boolean isFull() {
        return indx == arr.length;
    }

    // Display method to print all elements in the stack
    void display() {
        for (int i = 0; i < indx; i++) {
            System.out.print(arr[i] + " ");  // Print on the same line
        }
        System.out.println();  // Move to the next line after printing all elements
    }

    public static void main(String[] args) {
        Main st = new Main();
        st.push(3);
        st.push(2);
        st.push(6);
        st.push(5);
        st.push(4);
        st.display();
        System.out.println("Peek: " + st.peek());
        System.out.println("Size = " + st.size());
        st.pop();
        st.display();
    }
}
