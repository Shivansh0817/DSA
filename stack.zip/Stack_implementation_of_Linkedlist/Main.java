public class Main {
    Node head;
    int size = 0;

    class Node {
        Node next;
        int data;

        Node(int d) {
            data = d;
        }
    }

    void push(int d) {
        Node newnode = new Node(d);
        if (head == null) {
            head = newnode;
            size++;
            return;
        }
        newnode.next = head;
        head = newnode;
        size++;
    }

    int peek() {
        if (head == null) {
            System.out.println("Stack is empty");
            return -1;
        }
        return head.data;
    }

    int pop() {
        if (head == null) {
            System.out.println("Stack is empty");
            return -1;
        }
        int poppedData = head.data;
        head = head.next;
        size--;
        return poppedData;
    }

    void display() {
        Node temp = head;
        while (temp != null) {
            System.out.println(temp.data);
            temp = temp.next;
        }
    }

    public static void main(String args[]) {
        Main obj = new Main();
        obj.push(4);
        obj.push(5);
        obj.push(6);
        obj.display();
        System.out.println("Popped: " + obj.pop());
        obj.display();
    }
}
