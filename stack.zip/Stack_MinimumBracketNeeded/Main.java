import java.util.*;
public class Main 
{
    public static boolean isBalance(String s)
    {
        Stack<Character> st=new Stack<>();
        int n=s.length();
        for(int i=0;i<n;i++)
        {
            char ch=s.charAt(i);
            if(ch=='(')
            {
                st.push(ch);
            }
            else /*for closing bracket*/
            {
                if(st.size()==0)return false;
                if(st.peek()=='(')
                st.pop();
            }
        }
        if(st.size()>0)return false;
        else return true;
        
    }
    public static int Minimum(String s)
    {
          int n=s.length();
          int count=0,need=0;
        for(int i=0;i<n;i++)
        {
            char ch=s.charAt(i);
            if(ch=='(')
            {
                count++;
            }
            else if(ch==')')
            {
                if(count==0)
                need++;
                else
                count--;
            }
        }
        return need+count;
    }
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the String");
        String s=sc.nextLine();
        System.out.println(isBalance(s));
        System.out.println(Minimum(s));
        
    }
}